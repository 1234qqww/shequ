/**
 *
 * @param table
 * @param elem      //元素id
 * @param url       //请求地址
 * @param cols
 * @param page
 */
function base_table(table,elem,url,cols,page=false){
    if(!page) {
        page = {
            layout: ['count', 'prev', 'page', 'next'] //自定义分页布局
            , limit: 15
        }
    }
    table.render({
        elem: '#'+elem
        ,url: url //模拟接口/static/admin/json/useradmin/mangadmin.js
        ,parseData: function(res){//res 即为原始返回的数据
            return {
                "code": res.data.length>0?0:1, //解析接口状态
                "msg": res.data.length>0?'获取成功':(res.msg?res.msg:'暂无数据'), //解析提示文本
                "count": res.total, //解析数据长度
                "data": res.data, //解析数据列表
            };
        }
        ,cols: cols
        ,text: '对不起，加载出现异常！'
        ,page: page
    });
}
function ajax_post($,url,json){

    var post_load=layer.load();
    var result=[];
    $.ajaxSettings.async = false;
    $.post(url,json,function(res){
        layer.close(post_load);
        result=res;
    },'json');
    $.ajaxSettings.async = true;
    return result;
}
