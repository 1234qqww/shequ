/**
 * extend  ,hhtc: 'hhtc'
 * use:'hhtc'
 */
layui.define(["layer", "form"],function(exports){
    var $ = layui.$
        ,layer = layui.layer
        ,form = layui.form;
    var hhtc={
        upload_one:function(callback){
            layer.open({
                type: 2
                ,title: '单张图片上传'
                ,content: '/admin/upload/upload'
                ,area: ['600px', '600px']
                ,btn: ['确定', '取消']
                ,yes: function(index, layero){
                    var iframeWindow = window['layui-layer-iframe'+ index]
                        ,submit = layero.find('iframe').contents().find("#upload");
                    // console.log(iframeWindow.layui.form);
                    //监听提交
                    iframeWindow.layui.form.on('submit(upload)', function(data){
                        var field = data.field; //获取提交的字段
                        var img=field.img;
                        layer.close(index); //关闭弹层
                        callback(img)
                    });
                    submit.trigger('click');
                }
            });
        },

        upload_more:function(callback){
            layer.open({
                type: 2
                ,title: '多张图片上传'
                ,content: '/admin/upload/uploads'
                ,area: ['720px', '720px']
                ,btn: ['确定', '取消']
                ,yes: function(index, layero){
                    var iframeWindow = window['layui-layer-iframe'+ index]
                        ,submit = layero.find('iframe').contents().find("#upload");
                    //监听提交
                    iframeWindow.layui.form.on('submit(upload)', function(data){
                        var field = data.field; //获取提交的字段
                        console.log(field.img);
                        var str=field.img;
                        str=str.substring(0,str.length-1);
                        var img=str.split('-');//数组
                        layer.close(index); //关闭弹层
                        callback(img)
                    });
                    submit.trigger('click');
                }
            });
        },
        ajax:function(url,json,callback){
            var ajax_load=layer.load();
            $.post(url,json,function(res){
                layer.closeAll();
                callback(res);
            },'json')
        }
    }
    //输出接口
    exports('hhtc', hhtc);
})